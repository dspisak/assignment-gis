module CrashesHelper
end
