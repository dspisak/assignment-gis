class RoadsController < ApplicationController

	def index
		@roads = Road.all
		@roads_coords = []

		tmp = []
		@roads.each do |r|
			r.coords.points.each do |p|
				tmp << p.coordinates
			end
			@roads_coords << tmp
			tmp = []
				
		end
	end

	def show

	end

end
