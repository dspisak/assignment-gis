class CrashesController < ApplicationController
  def index
	@init = [Crash.first.coords.y, Crash.first.coords.x]
	@crashes = Crash.all
	@coords = []
#	@coords << [@crashes.first.coords.x, @crashes.first.coords.y]
	@color = true


	@crashes.each do |c|
		@coords << [c.coords.x, c.coords.y] if c.road_id == 3
	end
#	@crashes.each do |c|
#		@coords << [c.latlon.x, c.latlon.y]	
#	end
	
  end
end
