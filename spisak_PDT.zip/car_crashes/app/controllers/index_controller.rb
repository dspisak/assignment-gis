class IndexController < ApplicationController

	@@coords = Array.new
	@@cross_coords = Array.new
	@@cross_accid = Array.new
	@@p_coords = Array.new

	def index
		@roads_coords = @@coords
		@points_coords = @@p_coords
		@crosses_coords = @@cross_coords
		@cross_a = @@cross_accid
		@@coords = []
		@@p_coords = []
		@@cross_accid = []
		@@cross_coords = Array.new
		@start_point = [-93.596859, 41.588195]	
	end
	
	def tmp
		@slat = params[:sourceLat]
		@slng = params[:sourceLong]
		@dlat = params[:destLat]
		@dlng = params[:destLong]
		@show_crashes = params[:showCrashes]
		@year2013 = params[:year2013]
		@year2014 = params[:year2014]
		@year2015 = params[:year2015]
		@cross_a = []
		@points_coords = []
		@critic_cross = 0
		@riskant_cross = 0
		@safe_cross = 0
		
		@roads_coords = []
		line = Direction.getRoad(@slng, @slat, @dlng, @dlat)
		@@coords << line[0].coordinates
		@route_length = line[1]


		@start_point = line[0].start_point.coordinates


		accidents =  MyGeoQuery.getAccidents(line[0], @show_crashes, @year2013, @year2014, @year205)	
		@points_coords = @@p_coords = accidents[0]
	
		crosses = MyGeoQuery.getCrosses(line[0])


		crosses.each do |c|
			@@cross_coords << c
		end
		
	
		@length = MyGeoQuery.getLength(line[0]).to_f
	
		ca = MyGeoQuery.getCrossAccidents(@@cross_coords, @points_coords)

		ca[0].each do |c|
			@cross_a << c
			@@cross_accid << c
		end

		ca[1].each do |c|
			@critic_cross = @critic_cross + 1 if c > 20 
			@riskant_cross = @riskant_cross + 1 if c <= 20 && c > 3
			@safe_cross = @safe_cross + 1 if c <= 3
		end
	
		flash[:color] = @points_coords.size.to_f / (line[1]/1000).to_f

		if @show_crashes == "0"
			@@p_coords = []
			@critic_accid_num = accidents[1]
			@critic_nonaccid_num = @points_coords.size - accidents[1]
		elsif @show_crashes == "1"
			@critic_accid_num = accidents[1]
			@critic_nonaccid_num = @points_coords.size - accidents[1]
			@cross_a = []
			@@cross_accid = []
		elsif @show_crashes == "2"
			@critic_accid_num = @points_coords.size
			@critic_nonaccid_num = 0
		elsif @show_crashes == "3"
			@critic_accid_num = 0
			@critic_nonaccid_num = @points_coords.size 
		elsif @show_crashes == "4"
			@@p_coords = []
			flash[:color] = @cross_a.size.to_f / (line[1]/1000).to_f
			@critic_accid_num = 0
			@critic_nonaccid_num = 0
		end	
	
	
		render 'index'		
	
	end










	def cmt

#		@@coords = []
#		@@p_coords = Array.new
#		tmp = []
#		factory = RGeo::Geos.factory(:srid => 4326)
#		p1 = factory.point(@lng.to_f.round(7), @lat.to_f.round(7))
#		Road.all.each do |r|
#			if r.coords.distance(p1).round(7) < 0.0001
#				flash[:color] = r.crashes.size / (r.coords.length*10000)
#				@@coords << r.coords.coordinates
#				r.crashes.each do |c|
#					@@p_coords << [c.coords.x, c.coords.y]
#				end
#			end
#		end
		
	end

	helper_method :tmp
end
