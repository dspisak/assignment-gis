class Crash < ActiveRecord::Base
	belongs_to :road

end
