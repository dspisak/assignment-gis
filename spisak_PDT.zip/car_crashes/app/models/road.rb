class Road < ActiveRecord::Base
	has_many :crashes	

end
