require 'net/http'
require 'uri'

class Direction

def Direction.getRoad(point1x = 13.4301, point1y = 52.5109, point2x = 13.4265, point2y = 52.5080)
	points = "#{point1x.to_s},#{point1y.to_s};#{point2x.to_s},#{point2y.to_s}"
	
	url = createURL(points)
	uri = URI.parse(url)
	
	response = Net::HTTP.get_response(uri)
	
	coords = parseResponse(response)	
	distance = getDistance(response)
	line = createLine(coords)
	[line, distance]
end

private 

	def Direction.createLine(coords)
		factory = RGeo::Geos.factory(:srid => 4326)
		points = []
		coords.each do |x, y|
			x = x.to_f
			y = y.to_f
			points << factory.point(x, y)
		end
		factory.line_string(points)
	end
	
	def Direction.getDistance(response)
		json = JSON.parse(response.body)
		json["routes"][0].to_h["distance"].to_f
	end

	def Direction.parseResponse(response)
		json = JSON.parse(response.body)
		json["routes"][0].to_h["geometry"].to_h["coordinates"]
	end

	def Direction.createURL(url_points)
		url_address = "https://api.mapbox.com/directions/v5/mapbox/driving/"
		url_attributes = "?geometries=geojson&access_token=pk.eyJ1IjoiZHNwaXNhayIsImEiOiJjaXVibzJnbTUwMDBwMnRwaW91M3p6cTJiIn0.MVSpI0b4MyeUJTj-Bht7eA"
		url = url_address + url_points  + url_attributes
	end

end

#puts Direction.getRoad(-93.6471176147461, 41.595546971405014, -93.62565994262694, 41.59573953647872)
