#puts Crash.all.first.inspect


#factory = RGeo::Geographic.spherical_factory(:srid => 4326)
#factory = RGeo::Geos.factory(:srid => 4326)

#p00 = factory.point(16.9711048,48.1005701)
#p01 = factory.point(16.9719363,48.1014648)
#line =  factory.line_string([p00, p01])
#line0 =  factory.line_string([p00, p01])

#sql = "select * from crashes;"
#records_array = ActiveRecord::Base.connection.execute(sql)

#id = records_array[0]['id'].to_i
#id1 = records_array[1]['id'].to_i

#c = Crash.find(id).latlon
#c2 = Crash.find(id).latlon

#puts c.intersects?(c2)

#################################
#output = Array.new

#File.open('./lib/points.txt', 'r') do |f1|  
#  while line = f1.gets  
#    output << line  
#  end  
#end 

#factory = RGeo::Geos.factory(:srid => 4326)

#output.each do |o|
#	lat =  o.split(',')[0].to_f
#	long = o.split(',')[1].to_f
#	p00 = factory.point(long, lat)
#	c = Crash.new
#	c.latlon = p00;
#	puts c.inspect	
#	c.save	
#end
i = 0
Crash.all.each do |c| 
	n = rand(0..2)
	c.type = true if n == 0
	c.type = false if n == 1
	c.type = false if n == 2
	puts i
	i = i+1
	c.save
end

#Crashes.all.each do |r|
#	lng =  r.coords.length*10000
#	c =  r.crashes.size
#	puts c / lng
#	puts "***************"
#end
