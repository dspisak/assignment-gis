class MyGeoQuery
	
	def MyGeoQuery.getGeometry(s = Road.first.coords)
		sql = "select ST_GeomFromText(\'#{s}\', 4326) as geo;"
		res = Road.connection.execute(sql)
		res.first["geo"] 
	end

	def MyGeoQuery.getAccidents(road, type = nil, year2013=nil, year2014=nil, year2015=nil)
		year = ""
		result = []
		if (year2013 == "true")
			year = "\'2013\'"
		end 
		if (year2014 == "true" && year.empty?)
			year = year + "\'2014\'"
		elsif (year2014 == "true" && !year.empty?)
			year = year + ",\'2014\'"
		end 
		if (year2015 == "true" && year.empty?)
			year = year + "\'2015\'" 
		elsif (year2015 == "true" && !year.empty?)
			year = year + ",\'2015\'"
		end 
		
		if(!year.nil? && !year.empty?)
			road = MyGeoQuery.getGeometry(road)
			if(type == "0" || type == "1" || type == "4")
				sql = "select st_asgeojson(coords) as coords from crashes c where year in (#{year}) and st_distance(\'#{road}\', c.coords) < 0.0001;"
			elsif(type == "2")
				sql = "select st_asgeojson(coords) as coords from crashes c where c.critical=\'t\' and year in (#{year}) and st_distance(\'#{road}\', c.coords) < 0.0001;"
			elsif(type == "3")
				sql = "select st_asgeojson(coords) as coords from crashes c where c.critical=\'f\' and year in (#{year}) and st_distance(\'#{road}\', c.coords) < 0.0001;"
			end
		
			res = Road.connection.execute(sql)
			res.each_row do |r|
				result << r.to_s.split(":")[2].split("]")[0].split("[")[1].split(",")
			end
			sql = "select count(*) as num from crashes c where c.critical=\'t\' and year in (#{year}) and st_distance(\'#{road}\', c.coords) < 0.0001;"
			res = Road.connection.execute(sql)
			res = res.values[0][0].to_i
		end
		[result, res]
	end	
	
	def MyGeoQuery.getLength(road)
		road = MyGeoQuery.getGeometry(road)
		sql = "SELECT ST_Length_Spheroid(\'#{road}\', \'SPHEROID[\"WGS 84\",6378137,298.257223563]\')/1000 as km"
		res = Road.connection.execute(sql)
		res.values[0][0].to_f.round(3)
	end

	def MyGeoQuery.getCrosses(road)
		road = MyGeoQuery.getGeometry(road)
		sql = "select st_asgeojson(st_intersection(r.coords, \'#{road}\')) as coords from roads r where st_intersects(r.coords, \'#{road}\');"
		res = Road.connection.execute(sql)
		coords = []
		cross_lines = []
		res.each do |r|
			tmp = JSON.parse(r["coords"])
			coords << tmp["coordinates"] if tmp["type"] == "Point" 
		end
		coords
	end

	def MyGeoQuery.getCrossAccidents(crosses, accidents)
		factory = RGeo::Geos.factory(:srid => 4326)
		result = []
		accid_num = []
		accid_num_temp = 0

		crosses.each do |c|
			cross = factory.point(c[0], c[1])
			accidents.each do |a|
				accident = factory.point(a[0].to_f, a[1].to_f)
				if accident.distance(cross) < 0.0001
					result << accident.coordinates 
					accid_num_temp = accid_num_temp + 1
				end
			end
			accid_num << accid_num_temp
			accid_num_temp = 0
		end
		[result, accid_num]
	end


#dokoncit
	def MyGeoQuery.createCross(cross, road)
		factory = RGeo::Geos.factory(:srid => 4326)
		cross2 = MyGeoQuery.getGeometry(cross)
		road = MyGeoQuery.getGeometry(road)
		
		sql = "select st_astext(ST_ClosestPoint(\'#{cross2}\',\'#{road}\')) as res;"
		res = Road.connection.execute(sql)
		#p1 = factory.point(res.values.first.split(":")[3])
		res = res.values.to_s.split("(")[1].split(")")[0].split(" ")
		p01 = factory.point(res[0].to_f, res[1].to_f)
		cross = cross.split("(")[1].split(")")[0].split(" ")
		p02 = factory.point(cross[0].to_f, cross[1].to_f)
		line = factory.line_string([p01, p02])	
		puts line
	end

end

MyGeoQuery.getAccidents("road", true , true, false, true)

#geo = MyGeoQuery.getGeometry("LINESTRING (-93.647157 41.59564, -93.648686 41.595214, -93.652343 41.593878, -93.654656 41.593349, -93.65608 41.593321, -93.659355 41.593545, -93.659352 41.592683, -93.656116 41.592855, -93.654215 41.593117, -93.652037 41.593722, -93.647555 41.595344, -93.645584 41.595692, -93.635854 41.59589, -93.631958 41.595531, -93.625651 41.595202, -93.625654 41.595739)")

#c =  MyGeoQuery.getCrosses(geo)
#r = MyGeoQuery.getCrossAccidnets(c, [[-93.6522775047482, 41.5939019271688], [-93.6487627410592, 41.5951859644367], [-93.6486842719034, 41.595214481471]])

#puts r.inspect

#a = MyGeoQuery.createCross("POINT (-93.652343 41.593878)", "LINESTRING (-93.647157 41.59564, -93.648686 41.595214, -93.652343 41.593878, -93.654656 41.593349, -93.65608 41.593321, -93.659355 41.593545, -93.659352 41.592683, -93.656116 41.592855, -93.654215 41.593117, -93.652037 41.593722, -93.647555 41.595344, -93.645584 41.595692, -93.635854 41.59589, -93.631958 41.595531, -93.625651 41.595202, -93.625654 41.595739)")

