#puts Crash.all.first.inspect


#factory = RGeo::Geographic.spherical_factory(:srid => 4326)
#factory = RGeo::Geos.factory(:srid => 4326)

#p00 = factory.point(16.9711048,48.1005701)
#p01 = factory.point(16.9719363,48.1014648)
#line =  factory.line_string([p00, p01])
#line0 =  factory.line_string([p00, p01])

#sql = "select * from crashes;"
#records_array = ActiveRecord::Base.connection.execute(sql)

#id = records_array[0]['id'].to_i
#id1 = records_array[1]['id'].to_i

#c = Crash.find(id).latlon
#c2 = Crash.find(id).latlon

#puts c.intersects?(c2)

#################################
output = Array.new

File.open('./lib/roads7.txt', 'r') do |f1|  
  while line = f1.gets  
    output << line
  end  
end 

points = Array.new
factory = RGeo::Geos.factory(:srid => 4326)

0.upto(output.size-1) do |i|

	output[i].split(" ").map(&:to_f).each_slice(2) do |x,y|
#	puts x 
#	puts y
		points << factory.point(x, y)
	end




line0 =  factory.line_string(points)

r = Road.new
r.coords = line0
puts r.inspect
#r.save
points = []
end


#factory = RGeo::Geos.factory(:srid => 4326)

#output.each do |o|
#	lat =  o.split(',')[0].to_f
#	long = o.split(',')[1].to_f
#	p00 = factory.point(long, lat)
#	c = Crash.new
#	c.latlon = p00;
#	puts c.inspect	
#	c.save	
#end
