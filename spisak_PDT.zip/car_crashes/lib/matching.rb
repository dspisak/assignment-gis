Road.all.each do |r|
	Crash.all.each do |c|
		if r.coords.distance(c.coords) < 0.0001 
			c.road_id = r.id
			puts "zhoda"
			c.save
		end
	end
end
