require 'test_helper'

class RoadTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
