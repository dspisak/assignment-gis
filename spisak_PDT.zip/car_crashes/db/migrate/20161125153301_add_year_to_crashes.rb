class AddYearToCrashes < ActiveRecord::Migration
  def change
	add_column :crashes, :year, :integer	
  end
end
