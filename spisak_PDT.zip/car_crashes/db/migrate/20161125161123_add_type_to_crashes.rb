class AddTypeToCrashes < ActiveRecord::Migration
  def change
 	add_column :crashes, :type, :boolean
  end
end
