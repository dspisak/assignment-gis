class ChangeLatlonToCoords < ActiveRecord::Migration
  def change
 	rename_column :crashes, :latlon, :coords
  end
end
