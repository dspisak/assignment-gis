class AddRoadToCrashes < ActiveRecord::Migration
  def change
    add_reference :crashes, :road, index: true, foreign_key: true
  end
end
