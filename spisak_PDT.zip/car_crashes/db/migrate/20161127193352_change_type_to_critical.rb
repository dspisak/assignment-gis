class ChangeTypeToCritical < ActiveRecord::Migration
  def change
  	rename_column :crashes, :type, :critical
  end
end
