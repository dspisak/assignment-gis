class CreateRoads < ActiveRecord::Migration
  def change
    create_table :roads do |t|
      t.geometry :coords

      t.timestamps null: false
    end
  end
end
