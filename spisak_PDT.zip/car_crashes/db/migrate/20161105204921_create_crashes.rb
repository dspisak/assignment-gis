class CreateCrashes < ActiveRecord::Migration
  def change
    create_table :crashes do |t|
	  t.geometry :latlon

      t.timestamps null: false
    end
  end
end
